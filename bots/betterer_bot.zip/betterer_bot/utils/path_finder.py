import heapq
import math
from cambc import Position, Environment
from utils.tile_info import TileData
from utils.helper_functions import is_in_bound, direction_to_delta
from utils.constants import DeltaTypes
from utils.path_queue import PathQueue


class AStarPathfinder:

    def __init__(self, _map: list[TileData | None], w: int):
        self.map  = _map
        self.w    = w
        self.h    = len(_map) // w
        self.area = self.w * self.h

        area = self.area

        self._g_fwd  = [0.0] * area
        self._g_bwd  = [0.0] * area
        self._cf_fwd = [0]   * area
        self._cf_bwd = [0]   * area

        self._stamp_gf = [0] * area
        self._stamp_gb = [0] * area
        self._stamp_cf = [0] * area
        self._stamp_cb = [0] * area
        self._call_id  = 0

    # ─────────────────────────────────────────────────────────────────────────
    # Helpers
    # ─────────────────────────────────────────────────────────────────────────

    def idx(self, x: int, y: int) -> int:
        return y * self.w + x

    def heuristic(self, x, y, tx, ty, allow_diag):
        dx, dy = abs(x - tx), abs(y - ty)
        if allow_diag:
            return max(dx, dy) + (math.sqrt(2) - 1) * min(dx, dy)
        return dx + dy

    def is_passable(self, ni, walls, include_barriers=False):
        cell = self.map[ni]
        return cell is None or cell.passable(walls) or (not include_barriers and cell.destroyable())

    # ── Path reconstruction ───────────────────────────────────────────────────

    def reconstruct_path(self, came_from, start_i, current_i):
        w    = self.w
        path = []
        ci   = current_i
        while ci != start_i:
            path.append(Position(ci % w, ci // w))
            ci = came_from[ci]
        path.append(Position(start_i % w, start_i // w))
        path.reverse()
        return PathQueue(path)

    def reconstruct_path_bidir(
        self,
        came_from_fwd, stamp_cf,
        came_from_bwd, stamp_cb,
        start_i, meet_i, cid
    ):
        w   = self.w
        fwd = []

        # Forward half: meet_i → start_i
        ci = meet_i
        while ci != start_i:
            fwd.append(Position(ci % w, ci // w))
            ci = came_from_fwd[ci]
        fwd.append(Position(start_i % w, start_i // w))
        fwd.reverse()

        # Backward half: from meet_i's bwd parent toward goal seed
        ci = came_from_bwd[meet_i]
        while stamp_cb[ci] == cid and came_from_bwd[ci] != ci:
            fwd.append(Position(ci % w, ci // w))
            ci = came_from_bwd[ci]
        fwd.append(Position(ci % w, ci // w))

        return PathQueue(fwd)

    # ─────────────────────────────────────────────────────────────────────────
    # Main entry point
    # ─────────────────────────────────────────────────────────────────────────

    def run(
        self,
        origin:                  Position,
        target:                  Position,
        ignore_ores:             bool,
        delta_type:              DeltaTypes,
        target_distance_squared: int  = 0,
        bypass_wall:             bool = False,
        include_barriers:        bool = False,
    ):
        allow_diag = delta_type == DeltaTypes.ALL
        w          = self.w
        h          = self.h
        area       = self.area
        _map       = self.map

        walls = (
            {Environment.WALL}
            if ignore_ores
            else {Environment.WALL, Environment.ORE_TITANIUM, Environment.ORE_AXIONITE}
        )

        ox, oy  = origin.x, origin.y
        tx, ty  = target.x, target.y
        start_i = oy * w + ox

        # ── Trivial early exit ────────────────────────────────────────────────
        if (ox - tx) ** 2 + (oy - ty) ** 2 <= target_distance_squared:
            return PathQueue([Position(ox, oy)])

        deltas          = direction_to_delta(delta_type)
        cardinal_deltas = direction_to_delta(DeltaTypes.CARDINAL)
        is_bridge       = delta_type == DeltaTypes.BRIDGE

        # ── O(1) reset via call ID ────────────────────────────────────────────
        self._call_id += 1
        cid = self._call_id

        stamp_gf = self._stamp_gf
        stamp_gb = self._stamp_gb
        stamp_cf = self._stamp_cf
        stamp_cb = self._stamp_cb
        g_fwd    = self._g_fwd
        g_bwd    = self._g_bwd
        cf_fwd   = self._cf_fwd
        cf_bwd   = self._cf_bwd
        INF      = math.inf

        # ── Sanity: origin has a passable neighbor ────────────────────────────
        # For bridge mode use cardinal deltas for neighbor check
        sanity_deltas = cardinal_deltas if is_bridge else deltas
        has_fwd = False
        for ddx, ddy, _ in sanity_deltas:
            nx, ny = ox + ddx, oy + ddy
            if 0 <= nx < w and 0 <= ny < h:
                cell = _map[ny * w + nx]
                # barriers are always walkable (with cost), walls are not
                if cell is None or cell.passable(walls) or cell.destroyable():
                    has_fwd = True
                    break
        if not has_fwd:
            print(f"[ASTAR] FAILED (origin surrounded) origin=({ox},{oy}) target=({tx},{ty})")
            return None

        # ── Sanity: target has at least one walkable neighbor ─────────────────
        # Target itself may not be passable — we just need somewhere to expand from
        has_bwd = False
        for ddx, ddy, _ in sanity_deltas:
            nx, ny = tx + ddx, ty + ddy
            if 0 <= nx < w and 0 <= ny < h:
                cell = _map[ny * w + nx]
                if cell is None or cell.passable(walls) or cell.destroyable():
                    has_bwd = True
                    break
        if not has_bwd:
            print(f"[ASTAR] FAILED (target surrounded) origin=({ox},{oy}) target=({tx},{ty})")
            return None

        # ── Forward init ──────────────────────────────────────────────────────
        stamp_gf[start_i] = cid
        g_fwd[start_i]    = 0.0
        cf_fwd[start_i]   = start_i
        open_fwd          = [(0.0, start_i)]

        # ── Backward init ─────────────────────────────────────────────────────
        # Seed every cell within target_distance_squared of target.
        # bypass_wall=True  → seed regardless of cell content
        # bypass_wall=False → seed passable cells AND barriers (destroyable),
        #                     because barriers are walkable.
        # The target cell itself is always seeded so the backward search can
        # expand outward even if the cell is a wall — this is what makes
        # bidirectional work when the target is inside a wall.
        open_bwd = []
        r = int(math.isqrt(target_distance_squared))
        for dy in range(-r, r + 1):
            for dx in range(-r, r + 1):
                if dx * dx + dy * dy <= target_distance_squared:
                    nx, ny = tx + dx, ty + dy
                    if 0 <= nx < w and 0 <= ny < h:
                        ni   = ny * w + nx
                        cell = _map[ni]
                        # Always seed if bypass_wall, or if cell is walkable
                        # (passable or destroyable barrier), or it is the
                        # exact target cell (so backward can expand from it).
                        is_walkable = (
                            cell is None
                            or cell.passable(walls)
                            or cell.destroyable()
                        )
                        if bypass_wall or is_walkable or (nx == tx and ny == ty):
                            stamp_gb[ni] = cid
                            g_bwd[ni]    = 0.0
                            cf_bwd[ni]   = ni
                            heapq.heappush(open_bwd, (0.0, ni))

        if not open_bwd:
            print(f"[ASTAR] FAILED (no valid landing zone) origin=({ox},{oy}) target=({tx},{ty})")
            return None

        # ── Local aliases for hot loop ────────────────────────────────────────
        sqrt2m1  = math.sqrt(2) - 1
        heappush = heapq.heappush
        heappop  = heapq.heappop

        best      = INF
        meet_node = -1

        # Bridge uses cardinal only; switch to bridge deltas only on wall hit
        cur_deltas = cardinal_deltas if is_bridge else deltas

        # ── Main bidirectional loop ───────────────────────────────────────────
        while open_fwd and open_bwd:
            f_fwd = open_fwd[0][0]
            f_bwd = open_bwd[0][0]

            lower = f_fwd if f_fwd < f_bwd else f_bwd
            if meet_node != -1 and lower >= best:
                break

            # ── FORWARD expansion ─────────────────────────────────────────────
            if f_fwd <= f_bwd:
                f, ci = heappop(open_fwd)

                if stamp_cf[ci] == cid:
                    continue
                stamp_cf[ci] = cid

                cx   = ci % w
                cy   = ci // w
                g_ci = g_fwd[ci]

                if stamp_gb[ci] == cid:
                    candidate = g_ci + g_bwd[ci]
                    if candidate < best:
                        best      = candidate
                        meet_node = ci

                for ddx, ddy, penalty in cur_deltas:
                    nx = cx + ddx
                    ny = cy + ddy
                    if nx < 0 or nx >= w or ny < 0 or ny >= h:
                        continue
                    ni = ny * w + nx

                    if stamp_cf[ni] == cid:
                        continue

                    cell = _map[ni]

                    # ── Passability logic ─────────────────────────────────────
                    # None or passable  → free
                    # destroyable       → walkable, cost 5 (barrier)
                    # everything else   → true wall, only bridge-jump can pass
                    if cell is None or cell.passable(walls):
                        barrier_cost = 0
                        do_normal    = True
                    elif cell.destroyable():
                        # Barriers are ALWAYS walkable regardless of include_barriers
                        # include_barriers=False means treat as walkable with penalty
                        # include_barriers=True  means same (cost 5 either way)
                        barrier_cost = 5
                        do_normal    = True
                    else:
                        # True wall — only bridge jump can handle this
                        do_normal = False
                        if is_bridge:
                            # Only attempt jump if we are not at the origin
                            # (bridge not allowed at start)
                            if cx == ox and cy == oy:
                                continue
                            # Try all bridge deltas from current position
                            for bddx, bddy, bpen in deltas:
                                bnx = cx + bddx
                                bny = cy + bddy
                                if bnx < 0 or bnx >= w or bny < 0 or bny >= h:
                                    continue
                                bni = bny * w + bnx
                                if stamp_cf[bni] == cid:
                                    continue
                                bcell = _map[bni]
                                if bcell is None or bcell.passable(walls):
                                    bbc = 0
                                elif bcell.destroyable():
                                    bbc = 5
                                else:
                                    continue  # can't land on a true wall
                                new_g = g_ci + bpen + bbc
                                cur_g = g_fwd[bni] if stamp_gf[bni] == cid else INF
                                if new_g >= cur_g:
                                    continue
                                cf_fwd[bni]   = ci
                                g_fwd[bni]    = new_g
                                stamp_gf[bni] = cid
                                if stamp_gb[bni] == cid:
                                    candidate = new_g + g_bwd[bni]
                                    if candidate < best:
                                        best      = candidate
                                        meet_node = bni
                                dx_ = bnx - tx
                                dy_ = bny - ty
                                if allow_diag:
                                    adx = dx_ if dx_ >= 0 else -dx_
                                    ady = dy_ if dy_ >= 0 else -dy_
                                    h_val = (adx if adx > ady else ady) + sqrt2m1 * (adx if adx < ady else ady)
                                else:
                                    h_val = (dx_ if dx_ >= 0 else -dx_) + (dy_ if dy_ >= 0 else -dy_)
                                heappush(open_fwd, (new_g + h_val, bni))
                        continue  # true wall cell never added to path directly

                    if not do_normal:
                        continue

                    new_g = g_ci + penalty + barrier_cost
                    cur_g = g_fwd[ni] if stamp_gf[ni] == cid else INF
                    if new_g >= cur_g:
                        continue

                    cf_fwd[ni]   = ci
                    g_fwd[ni]    = new_g
                    stamp_gf[ni] = cid

                    if stamp_gb[ni] == cid:
                        candidate = new_g + g_bwd[ni]
                        if candidate < best:
                            best      = candidate
                            meet_node = ni

                    dx_ = nx - tx
                    dy_ = ny - ty
                    if allow_diag:
                        adx = dx_ if dx_ >= 0 else -dx_
                        ady = dy_ if dy_ >= 0 else -dy_
                        h_val = (adx if adx > ady else ady) + sqrt2m1 * (adx if adx < ady else ady)
                    else:
                        h_val = (dx_ if dx_ >= 0 else -dx_) + (dy_ if dy_ >= 0 else -dy_)
                    heappush(open_fwd, (new_g + h_val, ni))

            # ── BACKWARD expansion ────────────────────────────────────────────
            else:
                f, ci = heappop(open_bwd)

                if stamp_cb[ci] == cid:
                    continue
                stamp_cb[ci] = cid

                cx   = ci % w
                cy   = ci // w
                g_ci = g_bwd[ci]

                if stamp_gf[ci] == cid:
                    candidate = g_ci + g_fwd[ci]
                    if candidate < best:
                        best      = candidate
                        meet_node = ci

                for ddx, ddy, penalty in cur_deltas:
                    nx = cx + ddx
                    ny = cy + ddy
                    if nx < 0 or nx >= w or ny < 0 or ny >= h:
                        continue
                    ni = ny * w + nx

                    if stamp_cb[ni] == cid:
                        continue

                    cell = _map[ni]

                    if cell is None or cell.passable(walls):
                        barrier_cost = 0
                        do_normal    = True
                    elif cell.destroyable():
                        barrier_cost = 5
                        do_normal    = True
                    else:
                        do_normal = False
                        if is_bridge:
                            if cx == tx and cy == ty:
                                continue
                            for bddx, bddy, bpen in deltas:
                                bnx = cx + bddx
                                bny = cy + bddy
                                if bnx < 0 or bnx >= w or bny < 0 or bny >= h:
                                    continue
                                bni = bny * w + bnx
                                if stamp_cb[bni] == cid:
                                    continue
                                bcell = _map[bni]
                                if bcell is None or bcell.passable(walls):
                                    bbc = 0
                                elif bcell.destroyable():
                                    bbc = 5
                                else:
                                    continue
                                new_g = g_ci + bpen + bbc
                                cur_g = g_bwd[bni] if stamp_gb[bni] == cid else INF
                                if new_g >= cur_g:
                                    continue
                                cf_bwd[bni]   = ci
                                g_bwd[bni]    = new_g
                                stamp_gb[bni] = cid
                                if stamp_gf[bni] == cid:
                                    candidate = new_g + g_fwd[bni]
                                    if candidate < best:
                                        best      = candidate
                                        meet_node = bni
                                dx_ = bnx - ox
                                dy_ = bny - oy
                                if allow_diag:
                                    adx = dx_ if dx_ >= 0 else -dx_
                                    ady = dy_ if dy_ >= 0 else -dy_
                                    h_val = (adx if adx > ady else ady) + sqrt2m1 * (adx if adx < ady else ady)
                                else:
                                    h_val = (dx_ if dx_ >= 0 else -dx_) + (dy_ if dy_ >= 0 else -dy_)
                                heappush(open_bwd, (new_g + h_val, bni))
                        continue

                    if not do_normal:
                        continue

                    new_g = g_ci + penalty + barrier_cost
                    cur_g = g_bwd[ni] if stamp_gb[ni] == cid else INF
                    if new_g >= cur_g:
                        continue

                    cf_bwd[ni]   = ci
                    g_bwd[ni]    = new_g
                    stamp_gb[ni] = cid

                    if stamp_gf[ni] == cid:
                        candidate = new_g + g_fwd[ni]
                        if candidate < best:
                            best      = candidate
                            meet_node = ni

                    dx_ = nx - ox
                    dy_ = ny - oy
                    if allow_diag:
                        adx = dx_ if dx_ >= 0 else -dx_
                        ady = dy_ if dy_ >= 0 else -dy_
                        h_val = (adx if adx > ady else ady) + sqrt2m1 * (adx if adx < ady else ady)
                    else:
                        h_val = (dx_ if dx_ >= 0 else -dx_) + (dy_ if dy_ >= 0 else -dy_)
                    heappush(open_bwd, (new_g + h_val, ni))

        # ── Path reconstruction ───────────────────────────────────────────────
        if meet_node == -1:
            print(f"[ASTAR] FAILED origin=({ox},{oy}) target=({tx},{ty})")
            return None

        if stamp_gb[meet_node] == cid and cf_bwd[meet_node] == meet_node:
            path = self.reconstruct_path(cf_fwd, start_i, meet_node)
        else:
            path = self.reconstruct_path_bidir(
                cf_fwd, stamp_cf,
                cf_bwd, stamp_cb,
                start_i, meet_node, cid
            )

        barriers_crossed = sum(
            1 for pos in path._deque
            if _map[pos.y * w + pos.x] is not None
            and _map[pos.y * w + pos.x].destroyable()
        )
        print(f"[ASTAR] origin=({ox},{oy}) target=({tx},{ty}) "
              f"path_len={len(path)} barriers_crossed={barriers_crossed}")
        return path

    # ─────────────────────────────────────────────────────────────────────────
    # Debug
    # ─────────────────────────────────────────────────────────────────────────

    def debug_print_map(self, path, origin, target, walls, include_barriers=False, explored=None):
        """
        Legend:
          O  = origin       X  = target
          *  = path         B  = barrier (destroyable)
          #  = wall         f  = closed fwd only
          b  = closed bwd   +  = closed both.  = unvisited
        """
        path_coords = set()
        if path:
            for pos in path._deque:
                path_coords.add((pos.x, pos.y))

        explored = explored or {}
        ox, oy   = origin.x, origin.y
        tx, ty   = target.x, target.y

        print(f"    ", end="")
        for x in range(self.w):
            print(f"{x % 10}", end="")
        print()

        for y in range(self.h):
            print(f"{y:3} ", end="")
            for x in range(self.w):
                i    = y * self.w + x
                cell = self.map[i]

                if (x, y) == (ox, oy):
                    ch = "O"
                elif (x, y) == (tx, ty):
                    ch = "X"
                elif (x, y) in path_coords:
                    if cell is None:
                        ch = "*"
                    elif cell.destroyable():
                        ch = "B"
                    elif not cell.passable(walls):
                        ch = "#"
                    else:
                        ch = "*"
                elif i in explored:
                    side = explored[i]
                    if cell is not None and (cell.destroyable() or not cell.passable(walls)):
                        ch = "B" if cell.destroyable() else "#"
                    elif side == 'f':
                        ch = "f"
                    elif side == 'b':
                        ch = "b"
                    else:
                        ch = "+"
                else:
                    if cell is None:
                        ch = "."
                    elif cell.destroyable():
                        ch = "B"
                    elif not cell.passable(walls):
                        ch = "#"
                    else:
                        ch = "."
                print(ch, end="")
            print()